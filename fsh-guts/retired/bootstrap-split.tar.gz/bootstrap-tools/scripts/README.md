<!-- kg:subgraph:begin -->
# The tools

The schema generator and drawn schema page, the README writers (each directory's README, and the `kg:processes` and `kg:files` sections) with their Liquid templates, the [Process](../../bootstrap/schemas/README.md#process) renderer, the release-IRI sync, the term linker, and the checks: import closure, node identifiers, bootstrap's concepts, bootstrap's documents parsed against their Zod (`bootstrap:validate`), and the semver bump the published schemas require, computed from a diff (`bootstrap:semver`).

Part of [Bootstrap tools](../README.md) 0.1.0, declared as `bootstrap-tools-scripts`, holding `code`.

| file | what it is | used by |
|---|---|---|
| [`bootstrap-schema-page.test.ts`](bootstrap-schema-page.test.ts) | a file |  |
| [`bootstrap-schema-page.ts`](bootstrap-schema-page.ts) | a file |  |
| [`check-bootstrap-concepts.ts`](check-bootstrap-concepts.ts) | a file |  |
| [`check-closure.test.ts`](check-closure.test.ts) | a file |  |
| [`check-closure.ts`](check-closure.ts) | a file |  |
| [`check-node-iris.test.ts`](check-node-iris.test.ts) | a file |  |
| [`check-node-iris.ts`](check-node-iris.ts) | a file |  |
| [`export-graph.test.ts`](export-graph.test.ts) | a file |  |
| [`export-graph.ts`](export-graph.ts) | a file |  |
| [`gen-bootstrap-schemas.ts`](gen-bootstrap-schemas.ts) | a file |  |
| [`gen-vocabulary.test.ts`](gen-vocabulary.test.ts) | a file |  |
| [`gen-vocabulary.ts`](gen-vocabulary.ts) | a file |  |
| [`generated-by.test.ts`](generated-by.test.ts) | a file |  |
| [`generated-by.ts`](generated-by.ts) | a file |  |
| [`git-files.ts`](git-files.ts) | a file |  |
| [`iri-sync.ts`](iri-sync.ts) | a file |  |
| [`publish-files.test.ts`](publish-files.test.ts) | a file |  |
| [`publish-files.ts`](publish-files.ts) | a file |  |
| [`readme-graph-sections.test.ts`](readme-graph-sections.test.ts) | a file |  |
| [`readme-graph-sections.ts`](readme-graph-sections.ts) | a file |  |
| [`rehearse-standalone.ts`](rehearse-standalone.ts) | a file |  |
| [`render-bpmn.ts`](render-bpmn.ts) | a file |  |
| [`schema-semver.test.ts`](schema-semver.test.ts) | a file |  |
| [`schema-semver.ts`](schema-semver.ts) | a file |  |
| [`subgraph-readmes.test.ts`](subgraph-readmes.test.ts) | a file |  |
| [`subgraph-readmes.ts`](subgraph-readmes.ts) | a file |  |
| [`term-links.test.ts`](term-links.test.ts) | a file |  |
| [`term-links.ts`](term-links.ts) | a file |  |
| [`validate-bootstrap.test.ts`](validate-bootstrap.test.ts) | a file |  |
| [`validate-bootstrap.ts`](validate-bootstrap.ts) | a file |  |
| [`templates/`](templates/) | 3 files | |
<!-- kg:subgraph:end -->
